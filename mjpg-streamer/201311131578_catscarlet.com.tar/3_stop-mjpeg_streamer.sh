sudo killall mjpg_streamer

